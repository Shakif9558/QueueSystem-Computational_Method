function queueSystem()
    
iter = 0;  
d = 0; 
t = 0;

%userInput

disp('---------------Simulation of Queuing System---------------') 
n = input('Enter the starting point for the Service and Inter-Arrival time: '); 
cstNum = input('Enter the customer numbers: '); 
peakHours = input('Please choose the type of peak hours[1.Off  2.Moderate  3.High]: ');
fprintf('\n');

if( peakHours>3)
    disp('Peak Hour(s) must between 1-3');
elseif( peakHours<0)
    disp('Peak Hour(s) must between 1-3');
else

min = []; 
max = []; 
iTime = []; 
minService = []; 
maxService = []; 
sTime1 = [];
minF = [];
maxF =[];
FNum = [];
Price = [];
randS = floor(10*rand(3,10)+n); 
sum1 = 0; 
avgService = 0; 
avgService2 = 0; 
avgService3 = 0; 
avgSpend = 0; 
prob = 0;

%serviceTime
disp('------Service Time Sample Data------') 
disp('  Time  Probab.   CDF      Range    ')

inr = n;
serviceTime = n;

    for(i = inr:2:inr+8) 
        
        m = sum(randS(:) == i | randS(:) == i+1); 
        d = d + m/30; 
        minService = [minService; round(1+t)]; 
        maxService = [maxService; round(d*100)]; 
        sTime1 = [sTime1;serviceTime]; 
        fprintf('%4.0f     %4.2f    %4.2f   %3.0f - %3.0f\n',serviceTime, m/30,d ,round(1+t), round(d*100)) 
        t= d*100; 
        serviceTime = serviceTime + peakHours;
        inr = inr+1; 
    end 
    fprintf('\n')
    d = 0; 
    t = 0; 
    inr = n; 
    randI = floor(10*rand(3,10)+n);

%interArrivalTime
disp('---Inter Arrival Time Sample Data---') 
disp('  Time  Probab.   CDF      Range    ')  
    
    for(i = inr:2:inr+8) 
        intervalTime = inr; 
        m = sum(randI(:) == i | randI(:) == i+1); 
        d = d + m/30; 
        min = [min; round(1+t)]; 
        max = [max; round(d*100)]; 
        iTime = [iTime; intervalTime]; 
        fprintf('%4.0f     %4.2f    %4.2f   %3.0f - %3.0f\n',intervalTime, m/30,d , round(1+t), round(d*100)) 
        t= d*100; 
        inr = inr+1; 
    end 
    fprintf('\n')   
    d = 0; 
    t = 0; 
    inr = n; 
    randF = floor(10*rand(3,10)+n); 
 
%foodSample
disp('-----------------Food Sample Data----------------')  
disp('  Food_No.    Probab.   CDF      Range     Price ') 

    for(i = inr:2:inr+8) 
        FoodNmber = inr; 
        m = sum(randF(:) == i | randF(:) == i+1); 
        d = d + m/30; 
        minF = [minF; round(1+t)]; 
        maxF = [maxF; round(d*100)]; 
        FNum = [FNum; FoodNmber];
        FPrice = (10*rand+n);
        Price = [Price; FPrice]; 
        fprintf('  %4.0f         %4.2f    %4.2f   %3.0f - %3.0f    %4.2f\n' ,FoodNmber, m/30,d ,round(1+t), round(d*100), FPrice) 
        t= d*100; 
        inr = inr+1; 
    end 
    fprintf('\n')
    d = 0; 
    t = 0; 
    inr = n; 
    randF = floor(10*rand(3,10)+n); 
    
end

%server1
if (peakHours == 1) 
disp('--------------------------------------------------------------------------------------------------------------------------------------------------------')
disp('   |                       |    Server One   |                         |       | ')
disp('Cus| RN   IAT  AT  RN   ST | Begin  End   WT | RN    Food  Food  Total | Time  |            Service Details') 
disp('No.| Arr           ST      | Time   Time     | Food  No.   Qty   Price | Spend | ')
disp('--------------------------------------------------------------------------------------------------------------------------------------------------------')

rnArrival = 0; 
arrive = 0; 
inter = 0; 
rnService = 0; 
sTime2 = 0; 
lastArri = 0; 
lastService = 0; 
sBegin = 0; 
price = 0; 
foodNumber = 0;
    for(i = 1:cstNum) 

        rnService = floor(100*rand(1,1)+1); 
        rnFood = floor(100*rand(1,1)+1);
        Quantity = floor(10*rand(1,1)+1);
         if (i>1) 
             rnArrival = floor(100*rand(1,1)+1); 
         end 
      
         lastArri = sBegin; 
         lastService = sTime2; 
         for(j = 1:5) 
         
           if(min(j) <= rnArrival & rnArrival <= max(j)) 
                inter = iTime(j); 
                arrive = arrive + inter; 
            end 
            
            if(minService(j) <= rnService & rnService <= maxService(j)) 
                sTime2 = sTime1(j); 
            end 
            
            if(minF(j) <= rnFood & rnFood <= maxF(j)) 
                foodNumber = FNum(j);
                price = Price(j); 
            end 
            
         end 
         
       if(arrive < lastArri+lastService & i > 1) 
                sBegin = lastArri + lastService; 
         else 
            sBegin = arrive; 
            end  
       sEnd = sBegin + sTime2; 
       spendTime = sEnd - arrive;   
       waitingTime = sBegin - arrive; 
       sum1 = sum1 + waitingTime; 
       avgService = avgService + sTime2; 
       avgSpend = avgSpend + spendTime; 
       if (waitingTime > 0) 
           prob = prob+1; 
       end
     fprintf('%3.0f|%3.0f  %3.0f %3.0f  %3.0f %3.0f  | %3.0f   %3.0f  %3.0f  | %3.0f  %3.0f   %3.0f    %3.0f   | %3.0f   | ',i,rnArrival ,inter,arrive, rnService, sTime2, sBegin,sEnd,waitingTime,rnFood,foodNumber,Quantity,(Quantity*price),spendTime); 
     
     if(arrive~=0)
         fprintf('Customer %3.0f arrived at %3.0f and served by server %1.0f with %3.0f waiting time.\n',i,arrive,peakHours,waitingTime);
     else
         fprintf('No incoming customer(s).\n')
     end
    end
end

%server2
if (peakHours == 2) 
disp('------------------------------------------------------------------------------------------------------------------------------------------------------------------')
disp('   |                       |    Server One   |    Server Two   |                         |       | ')
disp('Cus| RN   IAT  AT  RN   ST | Begin  End   WT | Begin  End   WT | RN    Food  Food  Total | Time  |          Service Details') 
disp('No.| Arr           ST      | Time   Time     | Time   Time     | Food  No.   Qty   Price | Spend | ')
disp('------------------------------------------------------------------------------------------------------------------------------------------------------------------')
rnArrival = 0; 
arrive = 0; 
     inter = 0; 
rnService = 0; 
sTime2 = 0; 
lastArri = 0; 
lastService = 0; 
sBegin = 0; 
last2Arri = 0; 
last2Service = 0; 
s2Begin = 0; 
s2Time2 = 0; 
temp2Begin = 0; 
tempBegin = 0; 
temp2Time = 0; 
tempTime = 0; 
price = 0; 
foodNumber = 0;
     for(i = 1:cstNum) 
         
        rnService = floor(100*rand(1,1)+1);
        rnFood = floor(100*rand(1,1)+1);
        Quantity = floor(10*rand(1,1)+1); 
         if (i>1) 
        rnArrival = floor(100*rand(1,1)+1); 
         end 
         last2Arri = s2Begin; 
         last2Service = s2Time2; 
         lastArri = sBegin; 
         lastService = sTime2; 
         for(j = 1:5) 
           if(min(j) <= rnArrival & rnArrival <= max(j)) 
                inter = iTime(j); 
                arrive = arrive + inter; 
            end 
            
            if(minService(j) <= rnService & rnService <= maxService(j)) 
                a = sTime1(j); 
            end 
             

            if(minF(j) <= rnFood & rnFood <= maxF(j)) 
                foodNumber = FNum(j);
                price = Price(j); 
            end 
        end 
         if (i == 1) 
             sTime2 = a; 
         end 
       if(arrive < lastArri+lastService & i > 1) 
            if(arrive < last2Arri+last2Service) 
                if(lastArri+lastService < last2Arri+last2Service) 
                sBegin = lastArri + lastService; 
                sTime2 = a; 
                tempBegin = sBegin; 
                tempTime = sTime2; 
                s2Time2 = 0; 
                s2Begin = 0; 
  
                else 
                    s2Begin = last2Arri+last2Service; 
                    s2Time2 = a; 
                   temp2Begin = s2Begin; 
                   temp2Time = s2Time2; 
                    sTime2 = 0; 
                    sBegin = 0; 
                    %sEnd = '-'; 
                end 
            else 
                s2Begin = arrive; 
                s2Time2 = a; 
                temp2Begin = s2Begin; 
                temp2Time = s2Time2; 
                sTime2 = 0; 
                sBegin = 0; 
                %sEnd = 0; 
            end 
          else 
            sBegin = arrive; 
            sTime2 = a; 
            tempBegin = sBegin; 
            tempTime = sTime2; 
            s2Time2 = 0; 
            s2Begin = 0; 
            %s2End = 0; 
            end  
       sEnd = sBegin + sTime2; 
       s2End = s2Begin + s2Time2; 
       if (sEnd == 0) 
           spendTime = s2End - arrive; 
           waitingTime = s2Begin - arrive; 
       else 
           spendTime = sEnd - arrive; 
           waitingTime = sBegin - arrive; 
       end 
          sum1 = sum1 + waitingTime; 
          avgService = avgService2 + sTime2; 
          avgService2 = avgService2 + s2Time2; 
       avgSpend = avgSpend + spendTime; 
       if (waitingTime > 0) 
           prob = prob+1; 
       end 
        fprintf('%3.0f|%3.0f  %3.0f %3.0f  %3.0f %3.0f  | %3.0f   %3.0f  %3.0f  | %3.0f   %3.0f  %3.0f  | %3.0f  %3.0f   %3.0f    %3.0f   | %3.0f   | ',i,rnArrival ,inter,arrive, rnService, sTime2, sBegin,sEnd,s2Time2, s2Begin,s2End,waitingTime,rnFood,foodNumber,Quantity,(Quantity*price),spendTime); 

        if(arrive~=0)
            if(sTime2==0 && sBegin==0 && sEnd==0)
                fprintf('Customer %3.0f arrived at %3.0f and served by server %1.0f with %3.0f waiting time.\n',i,arrive,peakHours,waitingTime);
            elseif(s2Time2==0 && s2Begin==0 && s2End==0)
                fprintf('Customer %3.0f arrived at %3.0f and served by server 1 with %3.0f waiting time.\n',i,arrive,waitingTime);
            end            

        else
            fprintf('No incoming cutomer.\n');
        end
        
        s2Begin = temp2Begin; 
        s2Time2 = temp2Time; 
        sBegin = tempBegin; 
        sTime2 = tempTime;  
 
    end
    
end

%server3
if (peakHours == 3)
disp('-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------')
disp('   |                       |    Server One   |    Server Two   |   Server Three  |                         |       | ')
disp('Cus| RN   IAT  AT  RN   ST | Begin  End   WT | Begin  End   WT | Begin  End   WT | RN    Food  Food  Total | Time  |            Service Details') 
disp('No.| Arr           ST      | Time   Time     | Time   Time     | Time   Time     | Food  No.   Qty   Price | Spend | ')
disp('-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------')
rnArrival = 0; 
arrive = 0; 
inter = 0; 
rnService = 0; 
sTime2 = 0; 
lastArri = 0; 
lastService = 0; 
sBegin = 0; 
last2Arri = 0; 
last2Service = 0; 
s2Begin = 0; 
s2Time2 = 0; 
temp2Begin = 0; 
temp2Time = 0; 
tempBegin = 0; 
tempTime = 0; 
last3Arri = 0; 
last3Service = 0; 
s3Begin = 0; 
s3Time2 = 0; 
temp3Begin = 0; 
temp3Time = 0; 
price = 0; 
foodNumber = 0;

     for(i = 1:cstNum) 
         
        rnService = floor(100*rand(1,1)+1); 
        rnFood = floor(100*rand(1,1)+1);
        Quantity = floor(10*rand(1,1)+1);
         if (i>1) 
        rnArrival = floor(100*rand(1,1)+1); 
         end 
         last3Arri = s3Begin; 
         last3Service = s3Time2; 
         last2Arri = s2Begin; 
         last2Service = s2Time2; 
         lastArri = sBegin; 
         lastService = sTime2; 
         for(j = 1:5) 
           if(min(j) <= rnArrival & rnArrival <= max(j)) 
                inter = iTime(j); 
                arrive = arrive + inter; 
            end 
            
            if(minService(j) <= rnService & rnService <= maxService(j)) 
                a = sTime1(j); 
            end 
            if(minF(j) <= rnFood & rnFood <= maxF(j)) 
                foodNumber = FNum(j);
                price = Price(j); 
            end 
            
         end 
         if (i == 1) 
             sTime2 = a; 
         end 
       if(arrive < lastArri+lastService & i > 1) 
            if(arrive < last2Arri+last2Service) 
                 if(arrive < last3Arri+last3Service) 
                     if(lastArri+lastService < last2Arri+last2Service) 
                         if(lastArri+lastService < last3Arri+last3Service) 
                             sBegin = lastArri + lastService; 
                             sTime2 = a; 
                             tempBegin = sBegin; 
                             tempTime = sTime2; 
                             s2Time2 = 0; 
                             s2Begin = 0; 
                             s3Time2 = 0; 
                             s3Begin = 0; 
                         elseif (last3Arri+last3Service < last2Arri+last2Service) 
                             s3Begin = last3Arri+last3Service; 
                             s3Time2 = a; 
                             temp3Begin = s3Begin; 
                             temp3Time = s3Time2; 
                             sTime2 = 0; 
                             sBegin = 0; 
                             s2Time2 = 0; 
                             s2Begin = 0; 
                         else 
                             s2Begin = last2Arri+last2Service; 
                             s2Time2 = a; 
                             temp2Begin = s2Begin; 
                             temp2Time = s2Time2; 
                             sTime2 = 0; 
                             sBegin = 0; 
                             s3Time2 = 0; 
                             s3Begin = 0; 
                         end 
                     elseif (last2Arri+last2Service < last3Arri+last3Service) 
                         s2Begin = last2Arri+last2Service; 
                         s2Time2 = a; 
                         temp2Begin = s2Begin; 
                         temp2Time = s2Time2; 
                         sTime2 = 0; 
                         sBegin = 0; 
                         s3Time2 = 0; 
                         s3Begin = 0; 
                     else 
                          s3Begin = last3Arri+last3Service; 
                             s3Time2 = a; 
                             temp3Begin = s3Begin; 
                             temp3Time = s3Time2; 
                             sTime2 = 0; 
                             sBegin = 0; 
                             s2Time2 = 0; 
                             s2Begin = 0; 
                     end 
                 else 
                     s3Begin = arrive; 
                     s3Time2 = a; 
                     temp3Begin = s3Begin; 
                     temp3Time = s3Time2; 
                     sTime2 = 0; 
                     sBegin = 0; 
                     s2Time2 = 0; 
                     s2Begin = 0; 
                 end 
            else 
              s2Begin = arrive; 
              s2Time2 = a; 
              temp2Begin = s2Begin; 
              temp2Time = s2Time2; 
              sTime2 = 0; 
              sBegin = 0; 
              s3Time2 = 0; 
              s3Begin = 0; 
            end 
          else 
            sBegin = arrive; 
            sTime2 = a; 
            tempBegin = sBegin; 
            tempTime = sTime2; 
            s2Time2 = 0; 
            s2Begin = 0; 
            s3Time2 = 0; 
            s3Begin = 0; 
       end  
       sEnd = sBegin + sTime2; 
       s2End = s2Begin + s2Time2; 
       s3End = s3Begin + s3Time2; 
       if (sEnd == 0 & s3End == 0) 
           spendTime = s2End - arrive; 
           waitingTime = s2Begin - arrive; 
       elseif (s2End == 0 & s3End == 0) 
           spendTime = sEnd - arrive; 
           waitingTime = sBegin - arrive; 
       else 
           spendTime = s3End - arrive; 
           waitingTime = s3Begin - arrive; 
       end 
          sum1 = sum1 + waitingTime; 
          avgService = avgService + sTime2; 
          avgService2 = avgService2 + s2Time2; 
          avgService3 = avgService3 + s3Time2; 
       avgSpend = avgSpend + spendTime; 
       if (waitingTime > 0) 
           prob = prob+1; 
       end 
        fprintf('%3.0f|%3.0f  %3.0f %3.0f  %3.0f %3.0f  | %3.0f   %3.0f  %3.0f  | %3.0f   %3.0f  %3.0f  | %3.0f   %3.0f  %3.0f  | %3.0f  %3.0f   %3.0f    %3.0f   | %3.0f   | ',i,rnArrival ,inter, arrive, rnService, sTime2, sBegin,sEnd,s2Time2, s2Begin,s2End,s3Time2, s3Begin,s3End,waitingTime,rnFood,foodNumber,Quantity,(Quantity*price),spendTime); 
        
        if(arrive~=0)
            if(sTime2==0 && sBegin==0 && sEnd==0 && s2Time2==0 && s2Begin==0 && s2End==0)
                fprintf('Customer %3.0f arrived at %3.0f and served by server %1.0f with %3.0f waiting time.\n',i,arrive,peakHours,waitingTime);
            elseif(s2Time2==0 && s2Begin==0 && s2End==0 && s3Time2==0 && s3Begin==0 && s3End==0)
                fprintf('Customer %3.0f arrived at %3.0f and served by server 1 with %3.0f waiting time.\n',i,arrive,waitingTime);
            elseif(sTime2==0 && sBegin==0 && sEnd==0 && s3Time2==0 && s3Begin==0 && s3End==0)
                fprintf('Customer %3.0f arrived at %3.0f and served by server 2 with %3.0f waiting time.\n',i,arrive,waitingTime);
            end            

        else
            fprintf('No incoming cutomer.\n');
        end        
        
        s3Begin = temp3Begin; 
        s3Time2 = temp3Time; 
        s2Begin = temp2Begin; 
        s2Time2 = temp2Time; 
        sBegin = tempBegin; 
        sTime2 = tempTime; 

    end 
end

%calculate
if(peakHours==1)
    fprintf('\n');
    fprintf('Average waiting time : %2.2f\n',sum1/cstNum); 
    fprintf('Average spent time in system : %2.2f\n',avgSpend/cstNum); 
    fprintf('Average first service time in system : %2.2f\n',avgService/cstNum);   
    fprintf('Probability of customer(s) waiting in queue : %2.2f (%1.0f percent)\n',prob/cstNum,prob/cstNum*100); 
elseif(peakHours==2)
    fprintf('\n');
    fprintf('Average waiting time : %2.2f\n',sum1/cstNum); 
    fprintf('Average spent time in system : %2.2f\n',avgSpend/cstNum); 
    fprintf('Average first service time in system : %2.2f\n',avgService/cstNum);  
    fprintf('Average second service time in system : %2.2f\n',avgService2/cstNum); 
    fprintf('Probability of customer(s) waiting in queue : %2.2f (%1.0f percent)\n',prob/cstNum,prob/cstNum*100); 
elseif(peakHours==3)
    fprintf('\n');
    fprintf('Average waiting time : %2.2f\n',sum1/cstNum); 
    fprintf('Average spent time in system : %2.2f\n',avgSpend/cstNum); 
    fprintf('Average first service time in system : %2.2f\n',avgService/cstNum);  
    fprintf('Average second service time in system : %2.2f\n',avgService2/cstNum); 
    fprintf('Average third service time in system : %2.2f\n',avgService3/cstNum); 
    fprintf('Probability of customer(s) waiting in queue : %2.2f (%1.0f percent)\n',prob/cstNum,prob/cstNum*100); 
end
    
%prob
if(prob/cstNum<0.50)
    fprintf('Your server(s) is enough for your customers.\n');
else
    fprintf('Your server(s) is insufficient for your customers , please increase your server!\n');
end

fprintf('\n');
disp('------------------Simulation END--------------------');
disp('Student ID    Student Name    Group: TC04');
disp('----------------------------------------------------');
disp('1121116369    Fam Jiang Yuan');
disp('1141327731    Md Shakif Abdullah');
disp('1141328099    Rashed Mahade Barat');
disp('----------------------------------------------------');
fprintf('\n');

end  
